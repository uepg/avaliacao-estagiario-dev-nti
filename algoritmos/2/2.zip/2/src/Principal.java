
import Animais.Andorinha;
import Animais.Animal;
import Animais.Ave;
import Animais.Cao;
import Animais.Cavalo;
import Animais.Elefante;
import Animais.Galinha;
import Animais.Gato;
import Animais.Mamifero;
import Animais.Pato;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author ana
 */

public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        //Animal animal = new Animal();
        //Mamifero mamifero = new Mamifero();
        //Ave ave = new Ave();
        
        Cao cao = new Cao();
        cao.andar();
        cao.comer();
        cao.atacar();
        
        Gato gato = new Gato();
        gato.andar();
        gato.comer();
        //gato.setpatas(3);
        //System.out.println(gato.getpatas());
        
        Elefante elefante = new Elefante();
        elefante.andar();
        elefante.comer();
        
        Cavalo cavalo = new Cavalo();
        cavalo.andar();
        cavalo.comer();
        
        Andorinha andorinha = new Andorinha();
        andorinha.andar();
        andorinha.comer();
        andorinha.voar();
        
        Pato pato = new Pato();
        pato.andar();
        pato.comer();
        pato.voar();
        
        Galinha galinha = new Galinha();
        galinha.andar();
        galinha.comer();
    }
    
}
