/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animais;

/**
 *
 * @author ana
 */
public class Andorinha extends Ave implements Voo
{
    public Andorinha()
    { super (); }
    
    public void andar()
    {
        System.out.println("Sou uma " + this.getClass().getSimpleName() + " e estou andando.");
    }
    
     public void comer()
    {
        System.out.println("Sou uma " + this.getClass().getSimpleName() + " e estou comendo.");
    }
    
    @Override
    public void voar() 
    {
        System.out.println("Sou uma " + this.getClass().getSimpleName() + " e estou voando");
    }
}
