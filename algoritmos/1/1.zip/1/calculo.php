<?php

//Para funcionar, o 'banco' deve ser iniciado com 0 no arquivo 'vendas.txt'.

$total = 0.0;
$quantidadetotal = 0;
$file = fopen("vendas.txt", "a");
$lines = file("vendas.txt");
$newl = "";

for ($k=0; $k<sizeof($lines); $k++)
    $newl .= $lines[$k];

$newc = intval($lines[0])+1;
$c = $newc-1;
$txt = $newc . "\r\n" . $newl . "\r\n" . "Código da venda: " . $c . "\r\nItens (Nome do produto |  Quantidade |  Preço Individual):\r\n";
fclose($file);
$file = fopen("vendas.txt", "w");

for ($k=0; $k<4; $k++)
{
    $a = "a";
    $a .= $k;
    $b = "b";
    $b .= $k;
    if (isset($_POST[$a]) && isset($_POST[$b]))
    {
        $produto = $_POST[$a];
        $quantidade = $_POST[$b];
        $quantidadetotal = $quantidadetotal + intval($quantidade);
        if($produto == "Produto 1")
            $preco = 1.45;
        if($produto == "Produto 2")
            $preco = 3.50;
        if($produto == "Produto 3")
            $preco = 20.00;
        if($produto == "Produto 4")
            $preco = 45.90;
        $total = $total + floatval($preco)*intval($quantidade);
        $txt .= $produto . "|" . $quantidade . "|" . $preco . "\r\n";
    }
}
//Desconto aplicado sobre o total de produtos de toda a venda
if ($quantidadetotal > 10 && $quantidadetotal <= 20)
    $total = $total-($total*(5/100));
else if ($quantidadetotal > 20 && $quantidadetotal <= 30)
    $total = $total-($total*(10/100));
else if ($quantidadetotal > 30)
    $total = $total-($total*(20/100));

$txt .= "Total da venda com desconto: R$" . $total . "\r\n\r\n";
fwrite($file, $txt);
fclose($file);
?>