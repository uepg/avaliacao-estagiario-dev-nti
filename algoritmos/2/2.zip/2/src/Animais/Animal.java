/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animais;

/**
 *
 * @author ana
 */
public abstract class Animal 
{
    private float peso;
    private int patas;
    
    public Animal()
    {}
    
    public void setpeso(float peso)
    {
        this.peso = peso;
    }
    
    public void setpatas(int patas)
    {
        this.patas = patas;
    }
    
    public float getpeso()
    {
        return this.peso;
    }
    
    public int getpatas()
    {
        return this.patas;
    }
    
     public void andar()
    {
        System.out.println("Sou um " + this.getClass().getSimpleName() + " e estou andando.");
    }
    
     public void comer()
    {
        System.out.println("Sou um " + this.getClass().getSimpleName() + " e estou comendo.");

    }
}
