<html>
<!-- Obs.: Se puderem, usem o Chrome por conta do spinbox. -->

<?php
    include("header.php")
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 

<body>
        
        <table width="500px" align="center">
        <tr>
            <td valign="top">
            <label>Altere os produtos e quantidades abaixo conforme sua venda.
                Você pode adicionar mais produtos, se necessário, por meio do botão 
                "Adicionar mais produtos". Utilize o botão
                "Registrar venda" para salvar sua venda. Utilize o botão 
                "Registro de vendas" mais abaixo para ver o histórico de suas vendas.
            </td>
        </tr>
        </table>
    
    
        <br>
        
        <table width="250px" align="center">
            <tr>
                <td valign="top">
                    <div style="text-align:left;"><label>Produto</label></div>
                </td>
                <td valign="top">
                    <div style="text-align:left;"><label>Quantidade</label></div>
                </td>
            </tr>
        </table>
        
        <form name="rv" method="post" action="registrar.php">
        <table width="110px" align="center" id="tabela" name="tabela">
        <tr>
            <td valign="top">
            <select name = "a0">
            <option value = "Produto 1" selected>Produto 1</option>
            <option value = "Produto 2">Produto 2</option>
            <option value = "Produto 3">Produto 3</option>
            <option value = "Produto 4">Produto 4</option>
         </select>
            </td>
            <td valign="top">
                <input type="number" min="1" step="1" value="1" name="b0" size="6">
            </td>
        </tr>
        </table>

        <table width="300px" align="center">
        <tr>
        <td valign="top">
            <button type="button" name="add" id="add" class="btn btn-success">Adicionar mais produtos</button> <input type="submit" value="Registrar venda">
        </td>
        </tr>
        </form>
        </table>
        
        <br>
        <br>
        
        <form name="r" method="post" action="registros.php">
        <table width="500px" align="center">
        <tr>
        <td valign="top">
            <input type="submit" value="Registro de vendas">
        </td>
        </tr>
        </table>
</body>


 <script>
 $(document).ready(function(){  
      var i=0;  
      $('#add').click(function(){  
           i++; 
           $('#tabela').append('<tr id="row'+i+'"><td>\n\
   <select name = "a' + i + '">\
            <option value = "Produto 1" selected>Produto 1</option>\
            <option value = "Produto 2">Produto 2</option>\
            <option value = "Produto 3">Produto 3</option>\
            <option value = "Produto 4">Produto 4</option>\
         </select>\n\
         </td>\
            <td valign="top">\
                <input type="number" min="1" step="1" value="1" name="b' + i + '" size="6">\
            </td>\
\n\
</td>\n\
<td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
      $('#submit').click(function(){            
           $.ajax({  
                success:function(data)  
                {  
                     alert(data);  
                     $('#add_name')[0].reset();  
                }  
           });  
      });  
 });
 </script>
</html>