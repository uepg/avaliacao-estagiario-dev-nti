/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author luan0
 */
public class ModelProdutosVendasProdutos {
    
    private ModelProdutos modelProdutos;
    private ModelVendasProdutos modelVendasProdutos;
    private ModelProdutosVendasProdutos modelProdutosVendasProdutos;

    /**
     * @return the modelProdutos
     */
    public ModelProdutos getModelProdutos() {
        return modelProdutos;
    }

    /**
     * @param modelProdutos the modelProdutos to set
     */
    public void setModelProdutos(ModelProdutos modelProdutos) {
        this.modelProdutos = modelProdutos;
    }

    /**
     * @return the modelProdutosVendasProdutos
     */
    public ModelProdutosVendasProdutos getModelProdutosVendasProdutos() {
        return modelProdutosVendasProdutos;
    }

    /**
     * @param modelProdutosVendasProdutos the modelProdutosVendasProdutos to set
     */
    public void setModelProdutosVendasProdutos(ModelProdutosVendasProdutos modelProdutosVendasProdutos) {
        this.modelProdutosVendasProdutos = modelProdutosVendasProdutos;
    }

    /**
     * @return the modelVendasProdutos
     */
    public ModelVendasProdutos getModelVendasProdutos() {
        return modelVendasProdutos;
    }

    /**
     * @param modelVendasProdutos the modelVendasProdutos to set
     */
    public void setModelVendasProdutos(ModelVendasProdutos modelVendasProdutos) {
        this.modelVendasProdutos = modelVendasProdutos;
    }
    
    
}
