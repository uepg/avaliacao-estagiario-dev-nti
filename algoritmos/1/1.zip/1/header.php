<head>  
           <title>Sistema de vendas</title>
           <h2><center>Sistema de vendas</center></h2>
</head>  