<html>
<?php
    include("header.php")
?>

<body>
 
<?php
    include("calculo.php");
?>
 <table width="500px" align="center">
        <tr>
            <td valign="top">
                <label>Venda registrada!</label>
            </td>
            <td valign="top">
                <form action="index.php" method="post">
                    <input type="submit" value="Voltar">
                </form>
            </td>
 </table>

</body>
</html>