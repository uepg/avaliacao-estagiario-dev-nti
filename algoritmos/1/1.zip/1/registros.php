<html>
<?php
    include("header.php")
?>

<body>
 
 <table width="500px" align="center">
        <tr>
            <td valign="top">
            <?php
            $lines = file("vendas.txt");
            $c = intval($lines[0]);

            for ($k=$c+1; $k<sizeof($lines); $k++)
            {
                if ($lines[0] == "C")
                    echo "<br>";
                echo ($lines[$k] . "<br>");
                //echo lines[$k]; 
            }
            
            ?>
            </td>
        <tr>
            <td valign="top">
                <br>
                <br>
                <div style="text-align:right;">
                <form action="index.php" method="post">
                    <input type="submit" value="Voltar">
                </form>
                </div>
            </td>
        </tr>
 </table>

</body>
</html>