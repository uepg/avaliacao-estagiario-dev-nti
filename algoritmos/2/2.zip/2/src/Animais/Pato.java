/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Animais;

/**
 *
 * @author ana
 */
public class Pato extends Ave implements Voo
{
    public Pato()
    { super (); }
    
    @Override
    public void voar() 
    {
        System.out.println("Sou um " + this.getClass().getSimpleName() + " e estou voando");
    }
}
