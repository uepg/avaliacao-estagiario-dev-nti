Nesta questão, utilizei Java para resolver. Com a IDE netbeans, e o XAMPP com Sql.
Foi minha primeira interessão com um projeto assim. Nunca fiz nada tão complexo, achei bem trabalho fazer tudo e ainda sobraram muitos bugs
que não pude corrir por falta de tempo. Foi uma experiência consideravelmente cansativa, porém gratificante.
Tive que pesquisar muito, pois não tenho um conhecimento muito grande em Java.